package dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import bean.Admin;
import bean.User;

public class AdminDAO {

	// DB情報をフィールド変数に定義
	private static String RDB_DRIVE = "com.mysql.jdbc.Driver";
	private static String URL = "jdbc:mysql://localhost/systemdb";
	private static String USER = "root";
	private static String PASSWD = "root123";

	// DB接続を行うメソッド定義
	public static Connection getConnection() {
		try {
			Class.forName(RDB_DRIVE);
			Connection con = DriverManager.getConnection(URL, USER, PASSWD);
			return con;
		} catch (Exception e) {
			throw new IllegalStateException(e);

		}
	}

	// DBのuserinfoテーブルから指定ユーザーの条件に合致する情報を取得するメソッド
	public Admin selectByAdmin(String adminid) {

		// Userオブジェクト生成
		Admin admin = new Admin();

		Connection con = null;
		Statement smt = null;

		try {

			// SQL文を定義
			String sql = "SELECT * FROM admininfo where adminid='" + adminid + "'";

			con = AdminDAO.getConnection();
			smt = con.createStatement();

			// SQL文を発行して結果セットを受け取る
			ResultSet rs = smt.executeQuery(sql);

			while (rs.next()) {

				admin.SetAdminid(rs.getString("adminid"));
				admin.SetPassword(rs.getString("password"));

			}

		} catch (Exception e) {
			throw new IllegalStateException(e);
		} finally {
			if (smt != null) {
				try {
					smt.close();
				} catch (SQLException ignore) {
				}
			}
			if (con != null) {
				try {
					con.close();
				} catch (SQLException ignore) {
				}
			}
		}
		return admin;

	}

	// DBのuserinfoテーブルから指定ユーザーとパスワードの条件に合致する情報を取得するメソッド
	public Admin selectByAdmin(String adminid, String password) {

		// Userオブジェクト生成
		Admin admin = new Admin();

		Connection con = null;
		Statement smt = null;

		try {

			// SQL文を定義
			String sql = "SELECT * FROM admininfo where adminid='" + adminid + "' and password='" + password + "'";

			con = AdminDAO.getConnection();
			smt = con.createStatement();

			// SQL文を発行して結果セットを受け取る
			ResultSet rs = smt.executeQuery(sql);

			while (rs.next()) {
				admin.SetAdminid(rs.getString("adminid"));
				admin.SetPassword(rs.getString("password"));

			}

		} catch (Exception e) {
			throw new IllegalStateException(e);
		} finally {
			if (smt != null) {
				try {
					smt.close();
				} catch (SQLException ignore) {
				}
			}
			if (con != null) {
				try {
					con.close();
				} catch (SQLException ignore) {
				}
			}
		}
		return admin;

	}
}
