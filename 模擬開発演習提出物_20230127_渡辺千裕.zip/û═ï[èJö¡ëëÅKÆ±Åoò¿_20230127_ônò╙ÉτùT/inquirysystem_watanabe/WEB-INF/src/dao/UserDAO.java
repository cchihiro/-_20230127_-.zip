package dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.util.ArrayList;

import java.sql.Timestamp;

import bean.User;

public class UserDAO {
	private static String RDB_DRIVE = "com.mysql.jdbc.Driver";
	private static String URL = "jdbc:mysql://localhost/systemdb";
	private static String USER = "root";
	private static String PASSWD = "root123";

	public static Connection getConnection() {
		try {
			Class.forName(RDB_DRIVE);
			Connection con = DriverManager.getConnection(URL, USER, PASSWD);
			return con;
		} catch (Exception e) {
			throw new IllegalStateException(e);

		}
	}

	// ユーザーの全部の情報を持ってくるメソッド
	public ArrayList<User> selectAll() {

		ArrayList<User> list = new ArrayList<User>();
		String sql = "SELECT * FROM userinfo ORDER BY no DESC";

		Connection con = null;
		Statement smt = null;
		try {
			con = UserDAO.getConnection();
			smt = con.createStatement();

			ResultSet rs = smt.executeQuery(sql);

			while (rs.next()) {
				User user = new User();
				user.setNo(rs.getInt("no"));
				user.setName(rs.getString("name"));

				// 日付の格納
				// Timestamp型でrsから取得する
				Timestamp date = rs.getTimestamp("date");
				// フォーマットされた日付が入るString型変数の生成
				String d = "";
				// フォーマットを合わせる準備、取ってきたデータを("yyyyMMdd HH:mm:ss")のフォーマットに変換する
				SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd HH:mm");

				// 引数にしたTimestamp型のオブジェクトを指定のフォーマットに変換
				d = sdf.format(date);
				// フォーマットで整えられた日付（文字列）をDTOクラスのオブジェクトにセット
				user.setDate(d);

				// user.setDate(rs.getString("date"));
				user.setItem(rs.getString("item"));
				user.setInquiry(rs.getString("inquiry"));
				user.setReply(rs.getString("reply"));

				list.add(user);
			}

		} catch (Exception e) {
			throw new IllegalStateException(e);
		} finally {
			if (smt != null) {
				try {
					smt.close();
				} catch (SQLException ignore) {
				}
			}
			if (con != null) {
				try {
					con.close();
				} catch (SQLException ignore) {
				}
			}
		}
		return list;

	}

	// 書籍データを登録するインスタンスメソッド
	public void insert(User user) {
		Connection con = null;
		Statement smt = null;

		try {
			// 引数の情報を利用し、登録用のSQL文を文字列として定義
			String sql = "insert into userinfo values(NULL,'" + user.getName() + "','" + user.getEmail() + "','"
					+ user.getAddress() + "','" + user.getAge() + "','" + user.getGender() + "',now()" + ",'"
					+ user.getItem() + "','" + user.getInquiry() + "',NULL)";

			// getConnection()メソッドを利用してConnectionオブジェクトを生成
			con = UserDAO.getConnection();

			// createStatement（）メソッドを利用してStatementオブジェクトを生成
			smt = con.createStatement();

			// executeUpdate（）メソッドを利用して、①のSQL文を発行し書籍データを登録
			smt.executeUpdate(sql);

		} catch (Exception e) {
			throw new IllegalStateException(e);
		} finally {
			if (smt != null) {
				// Statementオブジェクトをクローズします。
				try {
					smt.close();
				} catch (SQLException ignore) {
				}
			}
			if (con != null) {
				// Connectionオブジェクトをクローズします。
				try {
					con.close();
				} catch (SQLException ignore) {
				}
			}
		}
	}

	// データベースから指定された書籍データを検索し格納するインスタンスメソッド
	public User selectByNo(int no) {

		Connection con = null;
		Statement smt = null;

		// Book型オブジェクト生成
		User user = new User();

		try {

			// 引数の情報を利用し、検索用のSQL文を文字列として定義
			String sql = "select * from userinfo where no=" + no;

			// getConnection()メソッドを利用してConnectionオブジェクトを生成
			con = UserDAO.getConnection();

			// createStatement（）メソッドを利用してStatementオブジェクトを生成
			smt = con.createStatement();

			// executeQuery（）メソッドを利用して、SQL文を発行し結果セットを取得
			ResultSet rs = smt.executeQuery(sql);

			// 結果セットから書籍データを取り出し、Bookオブジェクトに格納
			while (rs.next()) {
				user.setNo(rs.getInt("no"));
				user.setName(rs.getString("name"));
				user.setEmail(rs.getString("email"));
				user.setAddress(rs.getString("address"));
				user.setAge(rs.getString("age"));
				user.setGender(rs.getString("gender"));
				user.setDate(rs.getString("date"));
				user.setItem(rs.getString("item"));
				user.setInquiry(rs.getString("inquiry"));
				user.setReply(rs.getString("reply"));

			}

		} catch (Exception e) {
			throw new IllegalStateException(e);
		} finally {
			if (smt != null) {
				// Statementオブジェクトをクローズします。
				try {
					smt.close();
				} catch (SQLException ignore) {
				}
			}
			if (con != null) {
				// Connectionオブジェクトをクローズします。
				try {
					con.close();
				} catch (SQLException ignore) {
				}
			}
		}
		return user;
	}

	// 指定されたデータを更新するインスタンスメソッド
	public void update(User user) {

		Connection con = null;
		Statement smt = null;

		try {

			// 引数の情報を利用し、削除用のSQL文を文字列として定義
			String sql = "update userinfo set reply='" + user.getReply() + "' where no=" + user.getNo();

			// getConnection()メソッドを利用してConnectionオブジェクトを生成
			con = UserDAO.getConnection();

			// createStatement（）メソッドを利用してStatementオブジェクトを生成
			smt = con.createStatement();

			// executeUpdate（）メソッドを利用して、SQL文を発行し書籍データを更新
			smt.executeUpdate(sql);

		} catch (Exception e) {
			throw new IllegalStateException(e);
		} finally {
			if (smt != null) {
				// Statementオブジェクトをクローズします。
				try {
					smt.close();
				} catch (SQLException ignore) {
				}
			}
			if (con != null) {
				// Connectionオブジェクトをクローズします。
				try {
					con.close();
				} catch (SQLException ignore) {
				}
			}
		}
	}
}
