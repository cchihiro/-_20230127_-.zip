package bean;

public class User {
	// 変数定義
	private int no; // 連番
	private String name; // 名前
	private String email; // メールアドレス
	private String address; // メールアドレス
	private String age; // 年齢
	private String gender;// 性別
	private String date;// 日時
	private String item;// 項目
	private String inquiry;// 問い合わせ内容
	private String reply;// 返信

	// コンストラクタ定義
	public User() {
		this.no = 0;
		this.name = null;
		this.email = null;
		this.address = null;
		this.age = null;
		this.gender = null;
		this.date = null;
		this.item = null;
		this.inquiry = null;
		this.reply = null;
	}

	// アクセサメソッド
	public int getNo() {
		return this.no;
	}

	public void setNo(int no) {
		this.no = no;
	}

	public String getName() {
		return this.name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getEmail() {
		return this.email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getAddress() {
		return this.address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getAge() {
		return this.age;
	}

	public void setAge(String age) {
		this.age = age;
	}

	public String getGender() {
		return this.gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public String getDate() {
		return this.date;
	}

	public void setDate(String date) {
		this.date = date;
	}

	public String getItem() {
		return this.item;
	}

	public void setItem(String item) {
		this.item = item;
	}

	public String getInquiry() {
		return this.inquiry;
	}

	public void setInquiry(String inquiry) {
		this.inquiry = inquiry;
	}

	public String getReply() {
		return this.reply;
	}

	public void setReply(String reply) {
		this.reply = reply;
	}
}
