package bean;

public class Admin {

	// 変数定義
	private String adminid; // ユーザー名
	private String password; // パスワード

	// コンストラクタ定義
	public Admin() {
		this.adminid = null;
		this.password = null;
	}

	// アクセサメソッド
	public String getAdminid() {
		return this.adminid;
	}

	public void SetAdminid(String adminid) {
		this.adminid = adminid;
	}

	public String getPassword() {
		return this.password;
	}

	public void SetPassword(String password) {
		this.password = password;
	}

}
