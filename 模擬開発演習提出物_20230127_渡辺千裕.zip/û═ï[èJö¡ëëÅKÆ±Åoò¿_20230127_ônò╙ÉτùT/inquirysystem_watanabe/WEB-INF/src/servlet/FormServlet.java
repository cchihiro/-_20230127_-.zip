package servlet;

//概要：（ユーザー側）問い合わせ入力するプログラム
import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import bean.User;
import dao.UserDAO;

public class FormServlet extends HttpServlet {
	public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		String error = "";
		String cmd = "";
		String valit = "";

		try {

			// UserDAOクラスのオブジェクトを生成
			UserDAO userDao = new UserDAO();

			// 登録する書籍情報を格納するUserオブジェクトを生成
			User user = new User();

			// 画面からの入力情報を受け取るためのエンコードを設定
			request.setCharacterEncoding("UTF-8");

			// 年齢が正しく入力されていない(3桁以上)
			if (!request.getParameter("age").equals("")) {
				int age = Integer.parseInt(request.getParameter("age"));
				if (age > 120 || age < 0) {
					valit = "年齢が正しく入力されていません。";
					return;
				}
			}

			// 問い合わせ内容が200文字以上の場合
			if (request.getParameter("inquiry").length() > 200) {
				valit = "文字数は200までとなっております。";
				return;
			}

			// 画面からの入力情報を受け取り、Userオブジェクトに格納
			user.setName(request.getParameter("name"));
			user.setEmail(request.getParameter("email"));
			user.setAddress(request.getParameter("address"));
			user.setAge(request.getParameter("age"));
			user.setGender(request.getParameter("gender"));
			user.setItem(request.getParameter("item"));
			user.setInquiry(request.getParameter("inquiry"));

			// セッションにuserという名前で登録
			HttpSession session = request.getSession();
			session.setAttribute("prouser", user);

		} catch (IllegalStateException e) {// DB接続チェック
			error = "DB接続エラーの為、お問い合わせ登録は行えませんでした。";
			cmd = "top";

		} finally {
			if (error.equals("") && valit.equals("")) {
				// 「/view/formcheck.jsp」へフォワード
				request.getRequestDispatcher("/view/formCheck.jsp").forward(request, response);
			} else if (!valit.equals("")) {
				// 入力画面に戻す
				request.setAttribute("valit", valit);
				request.getRequestDispatcher("/view/form.jsp").forward(request, response);
			} else {
				request.setAttribute("error", error);
				request.setAttribute("cmd", cmd);
				request.getRequestDispatcher("/view/error.jsp").forward(request, response);

			}
		}
	}
}
