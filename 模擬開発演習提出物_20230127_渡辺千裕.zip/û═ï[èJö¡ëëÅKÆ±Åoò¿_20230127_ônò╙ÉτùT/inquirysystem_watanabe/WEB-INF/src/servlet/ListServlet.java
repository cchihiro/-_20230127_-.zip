package servlet;

//（管理者側）問い合わせ一覧表示を行うプログラム
import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import bean.Admin;
import bean.User;
import dao.UserDAO;

public class ListServlet extends HttpServlet {
	public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		String error = "";
		String cmd = "";

		try {
			// セッションから"adminid"を取得する。(セッション切れの場合はerror.jspに遷移する)
			HttpSession session = request.getSession();
			Admin admin = (Admin) session.getAttribute("admin");

			// セッション切れの判定
			if (admin == null) {
				error = "セッション切れの為、一覧表示できません";
				cmd = "logout";
				return;
			}

			// 画面から送信されるISBN情報を受け取るためのエンコードを設定
			request.setCharacterEncoding("UTF-8");

			// UserDAOクラスのオブジェクト生成
			UserDAO userDao = new UserDAO();

			// ユーザー情報を格納するArrayListオブジェクト
			ArrayList<User> list = new ArrayList<User>();

			// selectAllメソッドを呼び出し
			list = userDao.selectAll();

			// リクエストスコープにuserlistという名前で登録
			request.setAttribute("userlist", list);

		} catch (IllegalStateException e) {// DB接続チェック
			error = "DB接続エラーの為、一覧表示処理は行えませんでした。";
			cmd = "logout";

		} finally {
			if (error.equals("")) {
				// list.jspにフォワード
				request.getRequestDispatcher("/view/list.jsp").forward(request, response);
			} else {
				request.setAttribute("error", error);
				request.setAttribute("cmd", cmd);
				request.getRequestDispatcher("/view/error.jsp").forward(request, response);
			}
		}
	}
}
