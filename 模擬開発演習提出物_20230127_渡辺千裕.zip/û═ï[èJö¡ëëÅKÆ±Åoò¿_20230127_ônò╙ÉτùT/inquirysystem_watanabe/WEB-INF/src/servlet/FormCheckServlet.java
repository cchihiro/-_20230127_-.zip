package servlet;

//（ユーザー側）問い合わせ入力内容確認を行うプログラム
import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import bean.User;
import dao.UserDAO;

public class FormCheckServlet extends HttpServlet {
	public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		String error = "";
		String cmd = "";
		try {
			// UserDAOクラスのオブジェクトを生成
			UserDAO userDao = new UserDAO();

			// 登録する書籍情報を格納するUserオブジェクトを生成
			User user = new User();

			// 画面からの入力情報を受け取るためのエンコードを設定
			request.setCharacterEncoding("UTF-8");

			// 画面からの入力情報を受け取り、Userオブジェクトに格納
			user.setName(request.getParameter("name"));
			user.setEmail(request.getParameter("email"));
			user.setAddress(request.getParameter("address"));
			user.setAge(request.getParameter("age"));
			user.setGender(request.getParameter("gender"));
			user.setItem(request.getParameter("item"));
			user.setInquiry(request.getParameter("inquiry"));

			// insert（）メソッドを利用して、Userオブジェクトに格納された書籍データをデータベースに登録
			userDao.insert(user);

			// セッションにuserという名前で登録
			HttpSession session = request.getSession();
			session.setAttribute("user", user);

		} catch (IllegalStateException e) {// DB接続チェック
			error = "DB接続エラーの為、お問い合わせ登録は行えませんでした。";
			cmd = "top";

		} finally {
			if (error.equals("")) {
				// 「usersend」へフォワード
				request.getRequestDispatcher("/usersend").forward(request, response);
			} else {
				request.setAttribute("error", error);
				request.setAttribute("cmd", cmd);
				request.getRequestDispatcher("/view/error.jsp").forward(request, response);
			}
		}
	}
}
