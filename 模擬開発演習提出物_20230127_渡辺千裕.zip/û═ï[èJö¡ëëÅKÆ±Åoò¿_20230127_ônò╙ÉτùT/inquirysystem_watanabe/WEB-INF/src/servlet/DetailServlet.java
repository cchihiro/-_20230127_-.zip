package servlet;

//概要：（管理者側）問い合わせ詳細を表示するプログラム
import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import bean.Admin;
import bean.User;
import dao.UserDAO;

public class DetailServlet extends HttpServlet {
	public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		String error = "";
		String cmd = "";

		try {
			// セッションから"user"を取得する。(セッション切れの場合はerror.jspに遷移する)
			HttpSession session = request.getSession();
			Admin admin = (Admin) session.getAttribute("admin");

			// セッション切れの判定
			if (admin == null) {
				error = "セッション切れの為、詳細表示できません。";
				cmd = "logout";
				return;
			}

			// エンコードを設定
			request.setCharacterEncoding("UTF-8");

			// UserDAOクラスのオブジェクト生成
			UserDAO userDao = new UserDAO();

			// 表示するユーザー情報を格納するUserオブジェクトを生成
			User user = new User();

			// No情報を受け取る
			String strNo = request.getParameter("no");
			int no = Integer.parseInt(strNo);

			// selectByNo（）メソッドを利用してユーザー情報を取得
			user = userDao.selectByNo(no);

			// 取得したユーザー情報を「userinfo」という名前でセッションスコープに登録
			session.setAttribute("userinfo", user);

			// cmd情報を受け取る
			cmd = request.getParameter("cmd");
			request.setAttribute("cmd", cmd);

		} catch (IllegalStateException e) {// DB接続チェック
			error = "DB接続エラーの為、詳細表示は行えませんでした。";
			cmd = "logout";

		} finally {
			if (error.equals("")) {
				// detail.jspにフォワード
				request.getRequestDispatcher("/view/detail.jsp").forward(request, response);
			} else {
				request.setAttribute("error", error);
				request.setAttribute("cmd", cmd);
				request.getRequestDispatcher("/view/error.jsp").forward(request, response);
			}
		}
	}
}