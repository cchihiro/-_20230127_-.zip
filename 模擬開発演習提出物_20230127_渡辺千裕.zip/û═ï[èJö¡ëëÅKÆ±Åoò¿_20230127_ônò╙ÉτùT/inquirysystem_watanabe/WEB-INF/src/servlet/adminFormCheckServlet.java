package servlet;
//概要：（管理者側）入力内容の確認を行うプログラム
import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import bean.Admin;
import bean.User;
import dao.UserDAO;

public class adminFormCheckServlet extends HttpServlet {
	public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		String error = "";
		String cmd = "";

		try {
			// セッションから"admin"を取得する。(セッション切れの場合はerror.jspに遷移する)
			HttpSession session = request.getSession();
			Admin admin = (Admin) session.getAttribute("admin");

			// セッション切れの判定
			if (admin == null) {
				error = "セッション切れの為、返信メール送信はできませんでした。";
				cmd = "logout";
				return;
			}

			// UserDAOクラスのオブジェクトを生成
			UserDAO userDao = new UserDAO();

			// 画面からの入力情報を受け取るためのエンコードを設定
			request.setCharacterEncoding("UTF-8");

			// セッションスコープから情報を取得
			User user = (User) session.getAttribute("userinfo");

			// 画面からの入力情報を受け取り、Userオブジェクトに格納
			user.setReply(request.getParameter("reply"));

			// insert（）メソッドを利用して、Userオブジェクトに格納されたデータをデータベースに登録
			userDao.update(user);

			// 取得したユーザー情報を「userinfo」という名前でセッションスコープに登録
			session.setAttribute("userinfo", user);

		} catch (IllegalStateException e) {// DB接続チェック
			error = "DB接続エラーの為、返信メール送信はできませんでした。";
			cmd = "logout";

		} finally {
			if (error.equals("")) {
				// 「/mailSend.jsp」へフォワード
				request.getRequestDispatcher("/mailsend").forward(request, response);
			} else {
				request.setAttribute("error", error);
				request.setAttribute("cmd", cmd);
				request.getRequestDispatcher("/view/error.jsp").forward(request, response);
			}
		}
	}
}
