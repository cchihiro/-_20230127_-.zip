package servlet;
//概要：ユーザー側と管理者側へ画面遷移を分けるプログラム
import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import bean.Admin;
import dao.AdminDAO;

public class LoginServlet extends HttpServlet {
	public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		String error = "";
		String cmd = "";

		try {

			// 画面から送信されるISBN情報を受け取るためのエンコードを設定
			request.setCharacterEncoding("UTF-8");

			// adminid,password入力パラメータを取得する
			String adminid = request.getParameter("adminid");
			String password = request.getParameter("password");

			// UserDAOをインスタンス化し、関連メソッドを呼び出す
			AdminDAO admindao = new AdminDAO();
			Admin admin = admindao.selectByAdmin(adminid, password);

			if (admin.getAdminid() == null) {// User情報がない場合
				// リクエストスコープにエラーメッセージを設定
				error = "入力データが間違っています！";
				cmd="login";
				return;
			}

			// セッションオブジェクトの生成
			HttpSession session = request.getSession();

			// 取得したUserオブジェクトをセッションスコープに"user"という名前で登録する
			session.setAttribute("admin", admin);

			// クッキーに入力情報のadminidとpasswordを登録する（5日間）
			// ユーザーID用クッキーの生成
			Cookie useridCookie = new Cookie("adminid", adminid);
			useridCookie.setMaxAge(60 * 60 * 24 * 5);
			response.addCookie(useridCookie);

			// パスワード用クッキーの生成
			Cookie passwordCookie = new Cookie("password", password);
			passwordCookie.setMaxAge(60 * 60 * 24 * 5);
			response.addCookie(passwordCookie);

		} catch (IllegalStateException e) {// DB接続チェック
			error = "DB接続エラーの為、ログインはできません。";
			cmd = "login";

		} finally {
			if (error.equals("")) {
				// list.jspにフォワード
				request.getRequestDispatcher("/list").forward(request, response);
			} else {
				request.setAttribute("error", error);
				request.setAttribute("cmd", cmd);
				request.getRequestDispatcher("/view/error.jsp").forward(request, response);
			}
		}
	}
}
