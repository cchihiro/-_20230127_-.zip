package servlet;

//概要：ユーザーに返信メールを送信するプログラム
import java.io.IOException;

import javax.servlet.ServletException;
//お問い合わせに対しての返信を行うプログラム
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import bean.Admin;
import bean.User;
import dao.UserDAO;
import util.Sendmail;

public class MailSendServlet extends HttpServlet {
	public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		String error = "";
		String cmd = "";

		try {
			// セッションから"adminid"を取得する。(セッション切れの場合はerror.jspに遷移する)
			HttpSession session = request.getSession();
			Admin admin = (Admin) session.getAttribute("admin");

			// セッション切れの判定
			if (admin == null) {
				error = "セッション切れの為、返信メール送信できません";
				cmd = "logout";
				return;
			}

			// UserDAO各クラスをオブジェクト化
			UserDAO userDao = new UserDAO();

			// 画面からの入力情報を受け取るためのエンコードを設定
			request.setCharacterEncoding("UTF-8");

			// セッションスコープから"userinfo"を取得する
			User user = (User) session.getAttribute("userinfo");

			// メール文を入力
			String mail = user.getEmail();
			String title = "【神田英会話スクール】お問い合わせいただいた件につきまして";

			String msg = user.getName() + "様\r\n" + "\r\n" + "神田英会話スクールの白石と申します。\r\n"
					+ "この度はお問い合わせいただきまして誠にありがとうございます。\r\n" + "\r\n" + user.getReply() + "\r\n" + "神田英会話スクール　白石\r\n"
					+ "----------------------------------------------------------------\r\n" + "神田英会話スクール\r\n"
					+ "白石　大\r\n" + "TEL：xxx-xxxx-xxxx\r\n" + "mail:xxxx@xxxx.com\r\n"
					+ "-----------------------------------------------------------------";

			// 自動送信メールを送信する。
			Sendmail sendMail = new Sendmail();
			sendMail.sendMail(title, msg, mail);

		} catch (IllegalStateException e) {// DB接続チェック
			error = "DB接続エラーの為、返信メール送信は行えませんでした。";
			cmd = "logout";

		} finally {
			if (error.equals("")) {
				// 「/view/userSend.jsp」へフォワード
				request.getRequestDispatcher("/view/mailSend.jsp").forward(request, response);
			} else {
				request.setAttribute("error", error);
				request.setAttribute("cmd", cmd);
				request.getRequestDispatcher("/view/error.jsp").forward(request, response);
			}
		}
	}
}
